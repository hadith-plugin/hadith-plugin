"use strict";chrome.runtime.onInstalled.addListener(function(e){console.log("previousVersion",e.previousVersion)}),chrome.browserAction.setBadgeText({text:"حديث"});
//# sourceMappingURL=background.js.map
